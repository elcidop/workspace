<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statscarrier}prestashop>statscarrier_2e6774abc54cb13cef2c5bfd5a2cb463'] = 'Distribución por transportista';
$_MODULE['<{statscarrier}prestashop>statscarrier_b56f2e8e5f8694e8d09cbd8ec27c4e57'] = 'Añade un gráfico que muestra la distribución de cada transportista al Panel de control de Estadísticas.';
$_MODULE['<{statscarrier}prestashop>statscarrier_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Todos';
$_MODULE['<{statscarrier}prestashop>statscarrier_d7778d0c64b6ba21494c97f77a66885a'] = 'Filtrar';
$_MODULE['<{statscarrier}prestashop>statscarrier_ff61af405aa570a9000e6ba2da39857a'] = 'Este gráfico representa la distribución de transportistas para tus pedidos. Es posible limitarlo a un estado de pedido.';
$_MODULE['<{statscarrier}prestashop>statscarrier_998e4c5c80f27dec552e99dfed34889a'] = 'Exportar CSV';
$_MODULE['<{statscarrier}prestashop>statscarrier_ae916988f1944283efa2968808a71287'] = 'No hay pedidos validados para este periodo.';
$_MODULE['<{statscarrier}prestashop>statscarrier_d5b9d0daaf017332f1f8188ab2a3f802'] = 'Porcentaje de pedidos por transportista.';


return $_MODULE;
