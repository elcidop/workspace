<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'Boletín de noticias';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_5106250927c6e24c99601968284066de'] = 'Añade una pestaña con un gráfico que muestra los últimos registros producidos en el boletín de noticias al Panel de control de Estadísticas.';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_61a898af87607e3f4d41c3613d8761c7'] = 'Clientes suscritos:';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_7fe462207f98012d9ff00cf0e6633c94'] = 'Visitantes suscritos: ';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_64342cd480b27dfeefb08bace6e82fdc'] = 'Ambos:';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_998e4c5c80f27dec552e99dfed34889a'] = 'Exportar CSV';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_c01fb34ae495b6157666197caabdc303'] = 'El módulo "Bloque del Boletín de noticias" debe ser instalado.';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_cf74c2815ab62be1efa55a4a5d3f46a4'] = 'Estadísticas del Boletín de noticias';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_4b6f7d34a58ba399f077685951d06738'] = 'Clientes';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_ae5d01b6efa819cc7a7c05a8c57fcc2c'] = 'Visitantes';
$_MODULE['<{statsnewsletter}prestashop>statsnewsletter_130c5b3473c57faa76e2a1c54e26f88e'] = 'Ambos';


return $_MODULE;
