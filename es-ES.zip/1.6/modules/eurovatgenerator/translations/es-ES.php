<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{eurovatgenerator}prestashop>eurovatgenerator_267e605d64e4f9568839936222896911'] = 'Generador de IVA Europeo';
$_MODULE['<{eurovatgenerator}prestashop>eurovatgenerator_d30c038f173012c8bdbed1be880e05a0'] = 'Cumpla fácilmente con la nueva directiva europea sobre el IVA para productos virtuales.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_a73ab413109c43dd31f191a7d310e1ef'] = 'IVA Europeo para productos virtuales';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_c2ef886abacc6606f222e8a12eeac91c'] = 'Este módulo te ayuda a crear fácilmente los impuestos Europeos necesarios para que pueda cumplir con la nueva normativa del IVA en productos virtuales.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_47178f09d58b5d5c42576914ede0a423'] = 'Una vez creado, tendrás que modificar tu catálogo de productos asignando esta regla de impuestos europeos a los productos virtuales pertinentes.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_d234cb6833556b58cf492990ae9d704a'] = 'IVA por país';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_0f9f2ade08049f7b9300a6ef34949ed4'] = 'Para cada país, por favor, indica si el impuesto normal del IVA ya existe en tu tienda. Si no es así, se creará automáticamente.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_29ed28e68b5c3365164aa2e0ccbe57bf'] = 'El IVA ya existe en mi tienda';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_b0fa79d5e3f6e671af3a8150f86ef60c'] = 'El IVA no existe - se creará';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{eurovatgenerator}prestashop>configure_a73ab413109c43dd31f191a7d310e1ef'] = 'IVA Europeo para productos virtuales';
$_MODULE['<{eurovatgenerator}prestashop>configure_c2ef886abacc6606f222e8a12eeac91c'] = 'Este módulo te ayuda a crear fácilmente los impuestos Europeos necesarios para que pueda cumplir con la nueva normativa del IVA en productos virtuales.';
$_MODULE['<{eurovatgenerator}prestashop>configure_47178f09d58b5d5c42576914ede0a423'] = 'Una vez creado, tendrás que modificar tu catálogo de productos asignando esta regla de impuestos europeos a los productos virtuales pertinentes.';
$_MODULE['<{eurovatgenerator}prestashop>configure_d234cb6833556b58cf492990ae9d704a'] = 'IVA por país';
$_MODULE['<{eurovatgenerator}prestashop>configure_0f9f2ade08049f7b9300a6ef34949ed4'] = 'Para cada país, por favor, indica si el impuesto normal del IVA ya existe en tu tienda. Si no es así, se creará automáticamente.';
$_MODULE['<{eurovatgenerator}prestashop>configure_29ed28e68b5c3365164aa2e0ccbe57bf'] = 'El IVA ya existe en mi tienda';
$_MODULE['<{eurovatgenerator}prestashop>configure_b0fa79d5e3f6e671af3a8150f86ef60c'] = 'El IVA no existe - se creará';
$_MODULE['<{eurovatgenerator}prestashop>configure_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_7915b6921acab12d7737ea1810379b67'] = 'Todos los impuestos han sido creados. Una nueva regla de impuestos "IVA europeo para los productos virtuales" está ahora disponible.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_540fca2a5a01d285cd7509b98646cb14'] = '¿Qué debería hacer ahora?';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_892faeb6b5c1a83d8a8fa51562129449'] = 'Todos los impuestos han sido creados y reunidos bajo una nueva regla fiscal "IVA europeo para los productos virtuales".';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_e745e205828c0cddc2616ac37d06f35c'] = 'Ahora tienes que asignar esta nueva regla de impuestos a los productos virtuales que son susceptibles de ser afectados.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_2ef23860578d16db7a13ba8131362bba'] = 'También puedes eliminar este módulo de forma segura.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_05da7f6548358c48a37680f8c8845811'] = 'Ir al Catálogo';
$_MODULE['<{eurovatgenerator}prestashop>done_7915b6921acab12d7737ea1810379b67'] = 'Todos los impuestos han sido creados. Una nueva regla de impuestos "IVA europeo para los productos virtuales" está ahora disponible.';
$_MODULE['<{eurovatgenerator}prestashop>done_540fca2a5a01d285cd7509b98646cb14'] = '¿Qué debería hacer ahora?';
$_MODULE['<{eurovatgenerator}prestashop>done_892faeb6b5c1a83d8a8fa51562129449'] = 'Todos los impuestos han sido creados y reunidos bajo una nueva regla fiscal "IVA europeo para los productos virtuales".';
$_MODULE['<{eurovatgenerator}prestashop>done_e745e205828c0cddc2616ac37d06f35c'] = 'Ahora tienes que asignar esta nueva regla de impuestos a los productos virtuales que son susceptibles de ser afectados.';
$_MODULE['<{eurovatgenerator}prestashop>done_2ef23860578d16db7a13ba8131362bba'] = 'También puedes eliminar este módulo de forma segura.';
$_MODULE['<{eurovatgenerator}prestashop>done_05da7f6548358c48a37680f8c8845811'] = 'Ir al Catálogo';


return $_MODULE;
