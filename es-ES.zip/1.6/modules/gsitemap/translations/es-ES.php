<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{gsitemap}prestashop>gsitemap_3aaaafde6f9b2701f9e6eb9292e95521'] = 'Google sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_935a6bc13704a117d22333c3155b5dae'] = 'Genera tu archivo para Google Sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_b52bf50c73995780892b9945ddc98708'] = 'Se ha producido un error al comprobar los permisos del archivo. Por favor, ajusta los permisos para permitir que PrestaShop escriba un archivo en el directorio raíz.';
$_MODULE['<{gsitemap}prestashop>configuration_67ddb0d12fa1963b202d4ac310547709'] = 'Tu Sitemap se ha creado correctamente. Por favor, no olvides configurar la URL';
$_MODULE['<{gsitemap}prestashop>configuration_9d934413d2737c2a15f58de573657ce3'] = 'en tu cuenta de Google Webmaster.';
$_MODULE['<{gsitemap}prestashop>configuration_1c95b77d135b55c84429588c11697ea4'] = 'Tu Sitemap';
$_MODULE['<{gsitemap}prestashop>configuration_aa17b80751f4ae53ab8e3ed2fe99e94d'] = 'El Sitemap ya ha sido creado.';
$_MODULE['<{gsitemap}prestashop>configuration_a0bfb8e59e6c13fc8d990781f77694fe'] = 'Continuar';
$_MODULE['<{gsitemap}prestashop>configuration_9ab08b9ceeef857df07ad10e1de9301e'] = 'Por favor, configura la URL de tu Sitemap en tu cuenta de Google Webmaster:';
$_MODULE['<{gsitemap}prestashop>configuration_aef717e48ecd01989c92849d44bff9b6'] = 'Esta URL se corresponde con el archivo Sitemaps maestro. Éste se refiere a los siguientes archivos de sub-sitemap:';
$_MODULE['<{gsitemap}prestashop>configuration_0dbf904a2b27f036cf06741aad221ecc'] = 'Tu última actualización se realizó en esta fecha:';
$_MODULE['<{gsitemap}prestashop>configuration_6d37779958434303f8397436a1484ed8'] = 'Para un mejor aprovechamiento de este módulo, asegúrate de que tienes';
$_MODULE['<{gsitemap}prestashop>configuration_6a3282611e5ffb8539ce434133073f15'] = 'un valor mínimo de 128 MB en memory_limit.';
$_MODULE['<{gsitemap}prestashop>configuration_f891951357d4892887f0e416c54f972d'] = 'un valor mínimo de 30 segundos en max_execution_time.';
$_MODULE['<{gsitemap}prestashop>configuration_8156303464de0fba7cb8306cc768e998'] = 'Puedes modificar estos límites en el archivo php.ini. Para obtener más información, ponte en contacto con tu proveedor de alojamiento.';
$_MODULE['<{gsitemap}prestashop>configuration_0b9b4b91e0a8f59e264202a23d9c57a6'] = 'Configura tu Sitemap';
$_MODULE['<{gsitemap}prestashop>configuration_fe242b3dd3f455778072dc7042637a5e'] = 'Se generarán varios archivos Sitemaps dependiendo de cómo tu servidor esté configurado y del número de productos activados en tu catálogo.';
$_MODULE['<{gsitemap}prestashop>configuration_7f751d19f85d49a411d5691f5bb0b5f2'] = '¿Con qué frecuencia se actualiza tu tienda?';
$_MODULE['<{gsitemap}prestashop>configuration_f9f90eeaf400d228facde6bc48da5cfb'] = 'siempre';
$_MODULE['<{gsitemap}prestashop>configuration_745fd0ea7f576f350a0eed4b8c48a8e2'] = 'cada hora';
$_MODULE['<{gsitemap}prestashop>configuration_bea79186fd7af2da67e59b4b15df5a26'] = 'diariamente';
$_MODULE['<{gsitemap}prestashop>configuration_4a11fc05ed694c195f0703605b64da90'] = 'semanalmente';
$_MODULE['<{gsitemap}prestashop>configuration_708638881f3bac9d9c8c742c79502811'] = 'mensualmente';
$_MODULE['<{gsitemap}prestashop>configuration_1bf712896e6077fa0b708e911d8ee0b3'] = 'anualmente';
$_MODULE['<{gsitemap}prestashop>configuration_c7561db7a418dd39b2201dfe110ab4a4'] = 'nunca';
$_MODULE['<{gsitemap}prestashop>configuration_e51d91c7bfa9fc658b11afca4d84653c'] = 'Marca esta casilla si deseas comprobar la presencia de los archivos de imagen en el servidor';
$_MODULE['<{gsitemap}prestashop>configuration_05ff8159ccaef6f0f8391c61a6d0e631'] = 'marcar todas';
$_MODULE['<{gsitemap}prestashop>configuration_0dfcf5f2f5b9ab7c909f9bdca2b53b56'] = 'Indica las páginas que no quieres incluir en tu archivo Sitemaps:';
$_MODULE['<{gsitemap}prestashop>configuration_2ec111ec9826a83509c02bf5e6b797f1'] = 'Generar Sitemap';
$_MODULE['<{gsitemap}prestashop>configuration_ca99f8a0d484faef3a057fe7a5da3141'] = 'Esto puede tomar varios minutos';
$_MODULE['<{gsitemap}prestashop>configuration_162b34489ed8df561be1720f04fe6d42'] = 'Tienes dos maneras de generar el Sitemap:';
$_MODULE['<{gsitemap}prestashop>configuration_6caa369fd774beef106abbc5cc1e3368'] = 'Manualmente:';
$_MODULE['<{gsitemap}prestashop>configuration_4ed0b6a0097c3d38c43d756fe2653962'] = 'utilizando el formulario de arriba (tantas veces como sea necesario)';
$_MODULE['<{gsitemap}prestashop>configuration_3d263eb0233f14872193733387840c80'] = '-o-';
$_MODULE['<{gsitemap}prestashop>configuration_957d27165d1dc5947fb00e57967ffcce'] = 'Automáticamente:';
$_MODULE['<{gsitemap}prestashop>configuration_024d2d2f6d7fd575701fd1b30cc5c0c2'] = 'Contacta con tu proveedor de alojamiento para crear una "tarea Cron", que cargue la siguiente URL cada cierto tiempo:';
$_MODULE['<{gsitemap}prestashop>configuration_8076be06e575e50c7f9585271c8842ad'] = 'Esto generará automáticamente el XML de tu Sitemap.';
$_MODULE['<{gsitemap}prestashop>configuration_98a9d595be84a0687c4b26887977e0c3'] = 'desmarcar todas';


return $_MODULE;
