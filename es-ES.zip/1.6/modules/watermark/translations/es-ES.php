<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{watermark}prestashop>watermark_ee20bb60493f049175fc10c35acd2272'] = 'Marca de agua';
$_MODULE['<{watermark}prestashop>watermark_8d7c07bcea7e80d072308e4bd4cc37b0'] = 'Protege tus imagenes con una marca de agua.';
$_MODULE['<{watermark}prestashop>watermark_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = '¿Estás seguro de que quieres eliminar tus datos?';
$_MODULE['<{watermark}prestashop>watermark_2d38fba67823b23e2d5c93b5b8a5d707'] = 'Para que este módulo funcione correctamente, tienes que subir una imagen para utilizar como marca de agua.';
$_MODULE['<{watermark}prestashop>watermark_842262778d363362c95aa210c9752c25'] = 'La opacidad es requerida.';
$_MODULE['<{watermark}prestashop>watermark_9d1e7d4f41c6bcac92fa25f7f615c43e'] = 'La opacidad no está dentro del rango permitido.';
$_MODULE['<{watermark}prestashop>watermark_d31c2d99614d8e16430d2d8c99c1f2b0'] = 'La alineación Y es requerida.';
$_MODULE['<{watermark}prestashop>watermark_8fe9c39f4bf87082caabcf3650970c71'] = 'La alineación Y no está dentro del rango permitido.';
$_MODULE['<{watermark}prestashop>watermark_c2cf8e33c907a4cc689881dc8fa571c2'] = 'La alineación X es requerida.';
$_MODULE['<{watermark}prestashop>watermark_3a1f788dbe8957be92048606cf0d3fcb'] = 'La alineación X no está dentro del rango permitido.';
$_MODULE['<{watermark}prestashop>watermark_a9cac4be0fa0b815376b96f49e1435d7'] = 'Se requiere al menos un tipo de imagen.';
$_MODULE['<{watermark}prestashop>watermark_b670770ad59c1f8e7fb65f276074172b'] = 'La imagen debe estar en formato GIF.';
$_MODULE['<{watermark}prestashop>watermark_130aab6764f25267c79cef371270eb2a'] = 'Se ha producido un error al subir la marca de agua: %1$s en %2$s';
$_MODULE['<{watermark}prestashop>watermark_281bec6c0d3fed2b0f5839d1ee197a6e'] = 'La imagen de marca de agua no es realmente un GIF, por favor, CONVIERTA la imagen.';
$_MODULE['<{watermark}prestashop>watermark_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{watermark}prestashop>watermark_cc99ba657a4a5ecf9d2d7cb974d25596'] = 'Una vez que hayas configurado el módulo, regenera las imágenes utilizando la herramienta "Imágenes" en Preferencias. No obstante, la marca de agua se añadirá automáticamente a las nuevas imágenes.';
$_MODULE['<{watermark}prestashop>watermark_3dad9d209b698755340cd82c93fa299d'] = 'Archivo de marca de agua:';
$_MODULE['<{watermark}prestashop>watermark_ce4ca541df51a63fd8e78e0da29e1d44'] = 'La imagen debe estar en formato GIF';
$_MODULE['<{watermark}prestashop>watermark_e61514a08d28de6659551c6dce37dbed'] = 'Opacidad de la marca de agua (1-100)';
$_MODULE['<{watermark}prestashop>watermark_e4a60affa613d035430ab5b1f2c2dc40'] = 'Alineación X de la marca de agua:';
$_MODULE['<{watermark}prestashop>watermark_811882fecd5c7618d7099ebbd39ea254'] = 'izquierda';
$_MODULE['<{watermark}prestashop>watermark_4a548addbfb239bbd12f5afe11a4b6dc'] = 'en medio';
$_MODULE['<{watermark}prestashop>watermark_7c4f29407893c334a6cb7a87bf045c0d'] = 'derecha';
$_MODULE['<{watermark}prestashop>watermark_7c60ca861e403259d8a41b5e6577788c'] = 'Alineación Y de la marca de agua:';
$_MODULE['<{watermark}prestashop>watermark_b28354b543375bfa94dabaeda722927f'] = 'arriba';
$_MODULE['<{watermark}prestashop>watermark_71f262d796bed1ab30e8a2d5a8ddee6f'] = 'abajo';
$_MODULE['<{watermark}prestashop>watermark_27bd5f34e4375356363346e90dbbe2ca'] = 'Elige los tipos de imagen para proteger con la marca de agua:';
$_MODULE['<{watermark}prestashop>watermark_b48748047a9eed520aa26ae2a8b62905'] = 'Los clientes que han iniciado sesión ven las imágenes sin marca de agua';
$_MODULE['<{watermark}prestashop>watermark_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{watermark}prestashop>watermark_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{watermark}prestashop>watermark_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';


return $_MODULE;
