<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsregistrations}prestashop>statsregistrations_8b15fc6468c919d299f9a601b61b95fc'] = 'Cuentas cliente';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_f14056d6fef225c8aafd5a99d4c70fa8'] = 'Añade una pestaña de progreso de registro al Panel de control de Estadísticas.';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_247b3bdef50a59d5a83f23c4f1c8fa47'] = 'Número de visitantes que se detuvieron en el proceso de registro:';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_479c1246d97709e234574e1d2921994d'] = 'Número de visitantes que realizaron un pedido directamente después del registro:';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_a751e9cc4ed4c7585ecc0d97781cb48a'] = 'Total de cuentas cliente:';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_fba0e64541196123bbf8e3737bf9287b'] = 'Número de cuentas clientes creadas';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_76dcf557776c2b40d47b72ebcd9ac6b7'] = 'El número total de cuentas creadas no es en sí misma información importante. Sin embargo, es interesante analizar la cantidad creada en un cierto plazo. Esto indicará de una manera u otra si las cosas van por buen camino.';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_57a6f41a27c9baa5b402d30e97d4c1e8'] = '¿Cómo actuar sobre la evolución de los registros?';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_271ef73d55b8e3cc30963ca9413d4a52'] = 'Si dejas que tu tienda funcione sin cambiar nada, el número de registros de clientes debe permanecer estable o mostrar un ligero descenso.';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_bcabec23c8f36cecde037bd35ca4c709'] = 'Un aumento o dismininución significativa de registros de clientes muestra que probablemente hubo un cambio en tu tienda. Por lo tanto, debes identificarlo y dar marcha atrás si ha habido una disminución de suscripciones, ¡o continuar con éste si es beneficioso!';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_ded9c8756dc14fd26e3150c4718cd9d0'] = 'A continuación se muestra un resumen de factores que pueden influir en la creación de cuentas cliente:';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_87c365f80449f43460a0567d3b24f29f'] = 'Una campaña publicitaria puede atraer un mayor número de visitantes a tu tienda en línea. Esto probablemente será seguido por un aumento en las cuentas de los clientes y los márgenes de beneficio, que dependerá de la "calidad" del cliente. La publicidad bien orientada suele ser más efectiva que la publicidad a gran escala... ¡y también es más barata!';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_aa09be43df78c214e64ac3c3b255708e'] = 'Ofertas, promociones y/o concursos suelen crear grandes espectativas y curiosidad en los compradores. Ofreciendo tales cosas no sólo mantendrás tu negocio animado, sino que también aumentarás el tráfico, construirás la lealtad del cliente y cambiarás genuinamente tu filosofía actual de comercio electrónico.';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_8cb5605d77d1d2f9eab6191c0e027747'] = 'El diseño y la accesibilidad son más importantes que nunca: una mala accesibilidad o un tema gráfico mal elegido, puede hacer que tus visitantes se vayan. Esto significa que tienes que encontrar pra tu tienda en línea, un equilibrio perfecto entre belleza y funcionalidad.';
$_MODULE['<{statsregistrations}prestashop>statsregistrations_998e4c5c80f27dec552e99dfed34889a'] = 'Exportar CSV';


return $_MODULE;
