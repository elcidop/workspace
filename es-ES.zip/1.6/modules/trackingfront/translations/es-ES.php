<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{trackingfront}prestashop>trackingfront_e8a827db4eca37d2c6cdef8e406f6fa9'] = 'Afiliados - Acceso al Front Office de tu tienda';
$_MODULE['<{trackingfront}prestashop>trackingfront_d565f36c06949442a4eb998354376c5b'] = 'Permite a tus afiliados acceder a tus propias estadísticas. Véase Estadísticas/Referidos.';
$_MODULE['<{trackingfront}prestashop>trackingfront_8f5ac7793b2547cd025a7335f4934d26'] = 'es necesario iniciar sesión';
$_MODULE['<{trackingfront}prestashop>trackingfront_6f658a5bbec855ca5ae4ef4c94eb5d43'] = 'inicio de sesión no válido';
$_MODULE['<{trackingfront}prestashop>trackingfront_962c91be4b1056412febf0c272760814'] = 'la contraseña es requerida';
$_MODULE['<{trackingfront}prestashop>trackingfront_703c2b69e5d9f7072b7db5338214448b'] = 'contraseña no válida';
$_MODULE['<{trackingfront}prestashop>trackingfront_c41c77e4dddc04b1e0752a6050ae5656'] = 'error de autenticación';
$_MODULE['<{trackingfront}prestashop>trackingfront_10965b2740f42ad4887932c35cee26ab'] = 'Visitantes únicos';
$_MODULE['<{trackingfront}prestashop>trackingfront_ae5d01b6efa819cc7a7c05a8c57fcc2c'] = 'Visitantes';
$_MODULE['<{trackingfront}prestashop>trackingfront_d7e637a6e9ff116de2fa89551240a94d'] = 'Visitas';
$_MODULE['<{trackingfront}prestashop>trackingfront_d3139f39f1ad6324c80a9ddd50cc7867'] = 'Páginas vistas';
$_MODULE['<{trackingfront}prestashop>trackingfront_a28735af01fbb1e35371cb120985ac47'] = 'Registros';
$_MODULE['<{trackingfront}prestashop>trackingfront_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Pedidos';
$_MODULE['<{trackingfront}prestashop>trackingfront_2e27c4006a026eacfc1f85b41bf9bc4c'] = 'Comisión base';
$_MODULE['<{trackingfront}prestashop>trackingfront_86190054fc32554662ffbb12b717e8d0'] = 'Porcentaje por venta';
$_MODULE['<{trackingfront}prestashop>trackingfront_51d53cd2ecdae6b5dd3397875197e898'] = 'Pago por clic';
$_MODULE['<{trackingfront}prestashop>trackingfront_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventas';
$_MODULE['<{trackingfront}prestashop>trackingfront_da9cb586c6689202ca65cd77fd9b84ef'] = 'Carrito promedio';
$_MODULE['<{trackingfront}prestashop>trackingfront_200f5c9c419f0a53d5d361eff7b33abc'] = 'Tasa de registros';
$_MODULE['<{trackingfront}prestashop>trackingfront_89741aae300253f498b0993fa678fa18'] = 'Tasa de pedidos';
$_MODULE['<{trackingfront}prestashop>account_8954e140059f7b2544469f40161ba507'] = 'Espacio de afiliación';
$_MODULE['<{trackingfront}prestashop>account_c87aacf5673fada1108c9f809d354311'] = 'Cerrar sesión';
$_MODULE['<{trackingfront}prestashop>account_1dd1c5fb7f25cd41b291d43a89e3aefd'] = 'Hoy';
$_MODULE['<{trackingfront}prestashop>account_7cbb885aa1164b390a0bc050a64e1812'] = 'Mes';
$_MODULE['<{trackingfront}prestashop>account_537c66b24ef5c83b7382cdc3f34885f2'] = 'Año';
$_MODULE['<{trackingfront}prestashop>account_1e6d57e813355689e9c77e947d73ad8f'] = 'Desde:';
$_MODULE['<{trackingfront}prestashop>account_33caa076f23f453dd4061726f3706325'] = 'Hasta:';
$_MODULE['<{trackingfront}prestashop>account_5fa8aff419bb8e614b178cf1563ac13a'] = 'Mostrar detalles del producto';
$_MODULE['<{trackingfront}prestashop>account_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{trackingfront}prestashop>account_49ee3087348e8d44e1feda1917443987'] = 'Nombre';
$_MODULE['<{trackingfront}prestashop>account_ae5d01b6efa819cc7a7c05a8c57fcc2c'] = 'Visitantes';
$_MODULE['<{trackingfront}prestashop>account_d7e637a6e9ff116de2fa89551240a94d'] = 'Visitas';
$_MODULE['<{trackingfront}prestashop>account_453aceb005ceaf54a47da15fee8b2a26'] = 'Páginas';
$_MODULE['<{trackingfront}prestashop>account_591411cc8927851db2002208676d8330'] = 'Reg.';
$_MODULE['<{trackingfront}prestashop>account_a9841e29f2c8180709b16cd2a13c55fe'] = 'Ped.';
$_MODULE['<{trackingfront}prestashop>account_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventas';
$_MODULE['<{trackingfront}prestashop>account_a85eba4c6c699122b2bb1387ea4813ad'] = 'Carrito';
$_MODULE['<{trackingfront}prestashop>account_43005b13d452a4ad6f2d8e29b499c55a'] = 'Tasa de Reg.';
$_MODULE['<{trackingfront}prestashop>account_e14c8640d236365d11a060832b219a11'] = 'Tasa de Ped.';
$_MODULE['<{trackingfront}prestashop>account_316853cc3718335f11c048e33b9be98a'] = 'Clic';
$_MODULE['<{trackingfront}prestashop>account_b450fdef2453e92c31263a70f14fbd7b'] = '¤';
$_MODULE['<{trackingfront}prestashop>account_0bcef9c45bd8a48eda1b26eb0c61c869'] = '%';
$_MODULE['<{trackingfront}prestashop>header_bf15e68d25d8a2b7664950ba7385ed0a'] = 'Afiliación';
$_MODULE['<{trackingfront}prestashop>login_bf15e68d25d8a2b7664950ba7385ed0a'] = 'Afiliación';
$_MODULE['<{trackingfront}prestashop>login_8954e140059f7b2544469f40161ba507'] = 'Espacio de afiliación';
$_MODULE['<{trackingfront}prestashop>login_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Iniciar sesión';
$_MODULE['<{trackingfront}prestashop>login_dc647eb65e6711e155375218212b3964'] = 'Contraseña';


return $_MODULE;
