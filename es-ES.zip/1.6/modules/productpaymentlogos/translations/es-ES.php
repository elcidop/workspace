<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_1056d03db619b016d8fc6b60d08ef488'] = 'Bloque de logos de pago';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_88fd6d994459806f2dcb8999ac03c76e'] = 'Mostrar los logos de los métodos de pago disponibles en la página del producto.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_126b21ce46c39d12c24058791a236777'] = 'imagen no válida';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_df7859ac16e724c9b1fba0a364503d72'] = 'Se ha producido un error durante la subida del archivo.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_223795d3a336ef80c5b6a070ae4e0d2a'] = 'Encabezado del bloque';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_c7dd01cfb61ff8c984c0aff44f6540e3'] = 'Puedes optar por añadir un título por encima de los logos.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_89ca5c48bbc6b7a648a5c1996767484c'] = 'Imagen de bloque';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_9ce38727cff004a058021a6c7351a74a'] = 'Enlace de la imagen';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_826eeee52fe142372c3a2bc195eff911'] = 'Puede subir tu propia imagen utilizando el formulario de arriba, o enlazarla mediante la opción "Enlace de la imagen".';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';


return $_MODULE;
