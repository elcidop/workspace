<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsequipment}prestashop>statsequipment_247270d410e2b9de01814b82111becda'] = 'Navegadores y sistemas operativos';
$_MODULE['<{statsequipment}prestashop>statsequipment_2876718a648dea03aaafd4b5a63b1efe'] = 'Añade una pestaña con gráficos acerca del uso del navegador web y el sistema operativo al Panel de control de Estadísticas.';
$_MODULE['<{statsequipment}prestashop>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{statsequipment}prestashop>statsequipment_854c8e126f839cc861cde822b641230e'] = 'Asegúrate de que tu sitio web es accesible para tantas personas como sea posible';
$_MODULE['<{statsequipment}prestashop>statsequipment_0d5f13106dec10bb8a9301541052278c'] = 'Cuando gestionas un sitio web, es importante hacer un seguimiento de los programas informáticos utilizados por los visitantes con el fin de estar seguro de que el sitio se muestra de la misma manera para todos. PrestaShop fue construido para ser compatible con los navegadores web y sistemas operativos (OS) más recientes. Sin embargo, debido a que puedes añadir características avanzadas a tu sitio web o incluso modificar el código del núcleo de PrestaShop, estos añadidos pueden no ser accesibles a todos. Es por eso que es una buena idea llevar un registro del porcentaje de usuarios de cada tipo de software antes de añadir o cambiar algo al que sólo un número limitado de usuarios pueda acceder.';
$_MODULE['<{statsequipment}prestashop>statsequipment_11db1362a88c5e3e74c8f699c14d6798'] = 'Indica el porcentaje de cada navegador web utilizado por los clientes.';
$_MODULE['<{statsequipment}prestashop>statsequipment_998e4c5c80f27dec552e99dfed34889a'] = 'Exportar CSV';
$_MODULE['<{statsequipment}prestashop>statsequipment_90c58bfe4872fc9ca7bf6a181c3e5edd'] = 'Indica el porcentaje de cada sistema operativo utilizado por los clientes.';
$_MODULE['<{statsequipment}prestashop>statsequipment_bb38096ab39160dc20d44f3ea6b44507'] = 'Plug-ins';
$_MODULE['<{statsequipment}prestashop>statsequipment_9ffafc9e090c8e1c06f928ef2817efd6'] = 'Navegador utilizado';
$_MODULE['<{statsequipment}prestashop>statsequipment_0241b7aaaa5f76afd585bb6cdae314d1'] = 'Sistema operativo utilizado';


return $_MODULE;
