<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksharefb}prestashop>blocksharefb_d5d8d3eab66d27ce437e210d0ce31fce'] = 'Botón Compartir en Facebook';
$_MODULE['<{blocksharefb}prestashop>blocksharefb_1c32abb67032ad28e8613bb67f6e9867'] = 'Permite a los clientes compartir tus productos o contenidos en Facebook.';
$_MODULE['<{blocksharefb}prestashop>blocksharefb_353005a70db1e1dac3aadedec7596bd7'] = '¡Compartir en Facebook!';


return $_MODULE;
