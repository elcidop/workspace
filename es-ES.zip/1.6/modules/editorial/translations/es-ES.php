<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{editorial}prestashop>editorial_a46dcd3561c3feeb53903dfc0f796a35'] = 'Editor de textos de la página de inicio';
$_MODULE['<{editorial}prestashop>editorial_48b5a6f8c5a4e81cd8eb07678a981649'] = 'Un módulo de edición de texto para la página de inicio de tu tienda.';
$_MODULE['<{editorial}prestashop>editorial_5db205c79efd29b0e4f52d0c1ff45d20'] = 'Guardar ';
$_MODULE['<{editorial}prestashop>editorial_0245625ee10f9c6c0ed7f50eb1838856'] = 'Título principal';
$_MODULE['<{editorial}prestashop>editorial_4fb7f07fcf38a6401743822ade34e782'] = 'Aparece a lo largo de la parte superior de la página de inicio';
$_MODULE['<{editorial}prestashop>editorial_e1f46be647e598f00eeb0ab62561d695'] = 'Subtítulo';
$_MODULE['<{editorial}prestashop>editorial_bf75f228011d1443c4ea7aca23c3cff2'] = 'Texto de introducción';
$_MODULE['<{editorial}prestashop>editorial_617f7661941abbf06f773fcb10031c7a'] = 'Tu texto; por ejemplo: explica tu objetivo, destaca un nuevo producto, o describe un evento reciente.';
$_MODULE['<{editorial}prestashop>editorial_78587f196180054fcb797d40f4a86f10'] = 'Logo de la página de inicio';
$_MODULE['<{editorial}prestashop>editorial_28d74ee805e3a162047d8f917b74dcb3'] = 'Enlace del logo de la página de inicio';
$_MODULE['<{editorial}prestashop>editorial_98039e8f2a0d93fc0fff503f9166f59b'] = 'Subtítulo del logo de la página de inicio';
$_MODULE['<{editorial}prestashop>editorial_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{editorial}prestashop>editorial_2563cfff94f1447b53116f3089940125'] = 'Esta acción no se puede realizar.';
$_MODULE['<{editorial}prestashop>editorial_5526efd7014a00a73115bcf90883d968'] = 'Se ha producido un error durante la subida de la imagen.';
$_MODULE['<{editorial}prestashop>editorial_8dd2f915acf4ec98006d11c9a4b0945b'] = 'Configuración actualizada correctamente.';


return $_MODULE;
