<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Páginas no encontradas';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_607cc8b8993662a37cac86032fb071d2'] = 'Añade una pestaña al panel de Estadísticas, mostrando las páginas solicitadas por tus visitantes que no se han encontrado.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_dc3a3db6b98723bf91f924537a630600'] = 'La caché de "páginas no encontradas" ha sido vaciada.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_b323790d8ee3c43d317d19aea5012626'] = 'La caché de "páginas no encontradas" ha sido eliminada.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'errores 404';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_675f1f46497aeeee35832a5d9d095976'] = 'Un error 404 es un código de error HTTP que indica que el archivo solicitado por el usuario no se encuentra. En tu caso significa que uno de tus visitantes ha introducido una URL errónea en la barra de dirección de su navegador o que otra web tiene un enlace incorrecto establecido hacía tu tienda. Si no, lo más común es que sea un acceso directo, es decir, que cualquiera puede haber guardado un enlace como favorito en su navegador a un enlace que ya no existe.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_a90083861c168ef985bf70763980aa60'] = '¿Cómo capturar estos errores?';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_4f803d59ee120b11662027e049cba1f3'] = 'Si tu servidor web admite archivos .htaccess, puedes crear un directorio raíz de PrestaShop e insertar la siguiente línea dentro: "%s".';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_07e7f83ae625fe216a644d09feab4573'] = 'Un usuario que solicita una página que no existe será redirigido a la siguiente página: %s. Este módulo registra el acceso a esta página.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_01bd0bf7c5a68ad6ee4423118be3f7b6'] = 'Debes utilizar un archivo .htaccess para redireccionar los errores 404 a la página "404.php".';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Página';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Procedencia';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Contador';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_4a7a7e7cda40454cee7ec247660f8017'] = 'No se ha registrado ninguna "página no encontrada" por ahora.';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Suprimir';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_b9ae3636d6e672413a163f7cb34beb84'] = 'Vaciar TODAS las notificaciones de "páginas no encontradas" de este periodo';
$_MODULE['<{pagesnotfound}prestashop>pagesnotfound_0cf5c3a279c0e8c57b232d8c6bc3f06a'] = 'Vaciar TODAS las notificaciones de "páginas no encontradas"';


return $_MODULE;
