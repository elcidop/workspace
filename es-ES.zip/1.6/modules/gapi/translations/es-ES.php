<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{gapi}prestashop>gapi_69ee9bf9cf3d83a8468278c44959caf0'] = 'API de Google Analytics';
$_MODULE['<{gapi}prestashop>gapi_0851f7a0844553fa1168718de0f87262'] = 'No tienes permiso para abrir URLs externas';
$_MODULE['<{gapi}prestashop>gapi_6401593f1412a6b385c8e645d1f056ac'] = 'La librería cURL no está activada';
$_MODULE['<{gapi}prestashop>gapi_f8b94463fa8b5591e5edbbb8021e8038'] = 'OpenSSL no está activado';
$_MODULE['<{gapi}prestashop>gapi_6e4c3e76dd29876e6d33ce8c89e5fc5f'] = 'Google está inaccesible (comprueba tu cortafuegos)';
$_MODULE['<{gapi}prestashop>gapi_a1ed99ed6aaac91d7c3b127f032abf2d'] = 'Actualmente estás probando tu tienda en un servidor local. Con el fin de disfrutar de todas las características, es necesario instalar tu tienda en un servidor en línea.';
$_MODULE['<{gapi}prestashop>gapi_0237f944f5335bf28424f65ea896c22e'] = 'Por favor, ten en cuenta el módulo API de Google Analytics sólo funcionará si:';
$_MODULE['<{gapi}prestashop>gapi_cc45f699445b43bb53e2519f013fba91'] = 'has instalado y configurado el módulo de "Google Analytics"';
$_MODULE['<{gapi}prestashop>gapi_2d79f37dac5a9b0a1188bf50ed241c85'] = 'o ya ha introducido el script de Google Analytics en tu tienda.';
$_MODULE['<{gapi}prestashop>gapi_2ccf68a6aec8eda73156a7ef54b03351'] = '¿Qué versión de la API de Google Analytics quieres utilizar?';
$_MODULE['<{gapi}prestashop>gapi_0caf30452ef28d761ae80a407b64bd9b'] = 'v1.3: fácil de configurar aunque obsoleta y menos segura';
$_MODULE['<{gapi}prestashop>gapi_949617ff3314c7cf2d88d356a953bd67'] = 'v3.0 con OAuth 2.0: más potente y actualizada';
$_MODULE['<{gapi}prestashop>gapi_f1f4f41c5cab767032db832ec7bd5b64'] = 'Guardar y configurar';
$_MODULE['<{gapi}prestashop>gapi_00e9b476102174b72bce85f57ef4f251'] = 'Ayer, tu tienda recibió la visita de %d personas para un total de %d páginas vistas únicas.';
$_MODULE['<{gapi}prestashop>gapi_ac994aa3de9d2d547a386a0a05aaa4f9'] = 'Dirígete a https://code.google.com/apis/console y haz clic en el botón "Crear proyecto"';
$_MODULE['<{gapi}prestashop>gapi_8bc5a7586c07901e92c09835eb4bf999'] = 'En la pestaña "APIS & AUTH > APIs", activa la API Analytics';
$_MODULE['<{gapi}prestashop>gapi_cc33e14eed388f17b70ffdc1cf135e03'] = 'Se le solicitará que acepte los Términos y Condiciones del Servicio de Google API y Google Analytics';
$_MODULE['<{gapi}prestashop>gapi_6489ed26701b74c0fb139a3368804121'] = 'Obtendrá algo como esto';
$_MODULE['<{gapi}prestashop>gapi_ac868e51ad8cfbbe457407b4ed3a94ab'] = 'En la pestaña "APIS & AUTH > Credentials", haz clic en el primer botón rojo "Create new Client ID"';
$_MODULE['<{gapi}prestashop>gapi_d8334c85c0164bbdb0b24db654e6b611'] = 'Mantén seleccionado "Web application" y rellena el área "Authorized Javascript Origins" con "%s" y "%s", y luego el área "Authorized Redirect URI" con "%s" y "%s".';
$_MODULE['<{gapi}prestashop>gapi_4a7ee36b0b566be651113d36e6d87a86'] = 'A continuación, valida los datos haciendo clic en el botón "Create Client ID"';
$_MODULE['<{gapi}prestashop>gapi_6e1e99918b40cf3f46166fae1e642b73'] = 'Ahora debe tener la siguiente pantalla. Copia/Pega el "Client ID" y el "Client secret" en el formulario siguiente';
$_MODULE['<{gapi}prestashop>gapi_265c32931719280339cf19d733fea744'] = 'Ahora necesitas el ID del Perfil de Analytics que quieres conectar. Para encontrar tu ID de perfil, conéctate al panel de Analytics y mira la dirección URL en la barra de direcciones. Tu ID de perfil es el número que sigue al carácter "p", como se muestra subrayado en rojo en la captura de pantalla';
$_MODULE['<{gapi}prestashop>gapi_b18cb8e83113953f96bbe47bd90ab69c'] = 'Google Analytics API v3.0';
$_MODULE['<{gapi}prestashop>gapi_76525f0f34b48475e5ca33f71d296f3b'] = 'Client ID';
$_MODULE['<{gapi}prestashop>gapi_734082edf44417dd19cc65943aa65c36'] = 'Client Secret';
$_MODULE['<{gapi}prestashop>gapi_cce99c598cfdb9773ab041d54c3d973a'] = 'Perfil';
$_MODULE['<{gapi}prestashop>gapi_b1a026d322c634ca9e88525070e012fd'] = 'Guardar y autenticar';
$_MODULE['<{gapi}prestashop>gapi_d4e6d6c42bf3eb807b8778255a4ce415'] = 'Error de autenticación';
$_MODULE['<{gapi}prestashop>gapi_a670b4cdb42644e4b46fa857d3f73d9e'] = 'Google Analytics API v1.3';
$_MODULE['<{gapi}prestashop>gapi_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Dirección de correo electrónico';
$_MODULE['<{gapi}prestashop>gapi_dc647eb65e6711e155375218212b3964'] = 'Contraseña';
$_MODULE['<{gapi}prestashop>gapi_970a710b7344f8639b6a86d1f081b660'] = 'Puedes encontrar tu ID de perfil en la barra de direcciones de tu navegadoral acceder al informe de Analytics.';
$_MODULE['<{gapi}prestashop>gapi_e33d3b3409f8a0fcc326596c918c4961'] = 'En la ANTIGUA VERSIÓN de Google Analytics, la ID del perfil se encuentra en el parámetro "id" de la URL (véase "&id=xxxxxxxx"):';
$_MODULE['<{gapi}prestashop>gapi_c78fedea48082c7a437773e31b418f96'] = 'En la VERSIÓN ACTUAL de Google Analytics, la ID del perfil es el número que aparece al final de la URL, comenzando en el carácter p:';


return $_MODULE;
