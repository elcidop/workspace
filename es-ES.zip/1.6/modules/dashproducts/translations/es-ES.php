<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dashproducts}prestashop>dashproducts_6655df4af87b2038afd507a33545a56d'] = 'Panel de Productos';
$_MODULE['<{dashproducts}prestashop>dashproducts_4a528e24be5aca96e8a15b256efe1f31'] = 'Añade un bloque presentando en una tabla los últimos pedidos producidos en tu tienda y una clasificación de tus productos';
$_MODULE['<{dashproducts}prestashop>dashproducts_2ea989f83006e233627987293f4bde0a'] = 'Nombre del cliente';
$_MODULE['<{dashproducts}prestashop>dashproducts_068f80c7519d0528fb08e82137a72131'] = 'Productos';
$_MODULE['<{dashproducts}prestashop>dashproducts_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_MODULE['<{dashproducts}prestashop>dashproducts_58ef6750a23ba432fc1377b7de085d9f'] = 'Imp. excl.';
$_MODULE['<{dashproducts}prestashop>dashproducts_44749712dbec183e983dcd78a7736c41'] = 'Fecha';
$_MODULE['<{dashproducts}prestashop>dashproducts_ec53a8c4f07baed5d8825072c89799be'] = 'Estado';
$_MODULE['<{dashproducts}prestashop>dashproducts_3ec365dd533ddb7ef3d1c111186ce872'] = 'Datos';
$_MODULE['<{dashproducts}prestashop>dashproducts_be53a0541a6d36f6ecb879fa2c584b08'] = 'Imagen';
$_MODULE['<{dashproducts}prestashop>dashproducts_deb10517653c255364175796ace3553f'] = 'Producto';
$_MODULE['<{dashproducts}prestashop>dashproducts_3adbdb3ac060038aa0e6e6c138ef9873'] = 'Categoría';
$_MODULE['<{dashproducts}prestashop>dashproducts_2aed3d711270a6ed67d21ec2d7cd4af8'] = 'Totales vendidos';
$_MODULE['<{dashproducts}prestashop>dashproducts_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventas';
$_MODULE['<{dashproducts}prestashop>dashproducts_9e79098315622e58529d664b9a8b3cf8'] = 'Beneficio neto';
$_MODULE['<{dashproducts}prestashop>dashproducts_ed4832a84ee072b00a6740f657183598'] = 'Vistas';
$_MODULE['<{dashproducts}prestashop>dashproducts_2c04f1ad7694378897b98624780327ff'] = 'Añadir al carrito';
$_MODULE['<{dashproducts}prestashop>dashproducts_ce4ee01637f4279d02d0f232459dc9a4'] = 'Comprados';
$_MODULE['<{dashproducts}prestashop>dashproducts_37be07209f53a5d636d5c904ca9ae64c'] = 'Porcentaje';
$_MODULE['<{dashproducts}prestashop>dashproducts_1eb18ea1d018abef5759cef60ddc289b'] = 'Debes activar la opción "Guardar páginas vistas globales" del modulo "Datos para las estadísticas" con el fin de mostrar los productos más vistos, o utilizar el módulo de Google Analytics.';
$_MODULE['<{dashproducts}prestashop>dashproducts_cf5f3091e30dee6597885d8c0e0c357f'] = 'Término';
$_MODULE['<{dashproducts}prestashop>dashproducts_13348442cc6a27032d2b4aa28b75a5d3'] = 'Buscar';
$_MODULE['<{dashproducts}prestashop>dashproducts_fd69c5cf902969e6fb71d043085ddee6'] = 'Resultados';
$_MODULE['<{dashproducts}prestashop>dashproducts_38fb7d24e0d60a048f540ecb18e13376'] = 'Guardar';
$_MODULE['<{dashproducts}prestashop>dashproducts_ea4788705e6873b424c65e91c2846b19'] = 'Cancelar';
$_MODULE['<{dashproducts}prestashop>dashproducts_85bf7474324d7d02725e4dca586afcd9'] = 'Número de "Pedidos Recientes" a mostrar';
$_MODULE['<{dashproducts}prestashop>dashproducts_735b8c7f6d50b4c6f818deeab3cdea4a'] = 'Número de "Más Vendidos" a mostrar';
$_MODULE['<{dashproducts}prestashop>dashproducts_14d24dddc4c67abf8364b980b2ccd5a2'] = 'Número de "Más vistos" a mostrar';
$_MODULE['<{dashproducts}prestashop>dashproducts_f1ee1eaab342241138d45f35f4d8466a'] = 'Número de "Más buscados" a mostrar';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_3e361ce73ecabd6524af286d55809ed7'] = 'Productos y Ventas';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_f1206f9fadc5ce41694f69129aecac26'] = 'Configurar';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_63a6a88c066880c5ac42394a22803ca6'] = 'Actualizar';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_254f642527b45bc260048e30704edb39'] = 'Configuración';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_fd3458547ef9c3a8bd0e1e1b4ef2b4dd'] = 'Pedidos recientes';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_d7b2933ba512ada478c97fa43dd7ebe6'] = 'Los más vendidos';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_be5006eb5af9ab6dbca803f8d3065bbc'] = 'Más Vistos';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_1eb5e5713d7363e921dd7f5500b6d212'] = 'Más buscados';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_3d23ac9ab254a9f1014c3a859b01bcfc'] = 'Últimos %d pedidos';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_82f0f8d535196ce2a6ea16652d981f94'] = 'Los mejores %d productos';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_5da618e8e4b89c66fe86e32cdafde142'] = 'Desde';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_01b6e20344b68835c5ed1ddedf20d531'] = 'hasta';
$_MODULE['<{dashproducts}prestashop>dashboard_zone_two_1daaca459ce1e6610e0b97a9ad723f27'] = 'Los %d términos más buscados';


return $_MODULE;
