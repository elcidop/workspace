<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockadvertising}prestashop>blockadvertising_bedd646b07e65f588b06f275bd47be07'] = 'Bloque de Publicidad';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_dc23a0e1424eda56d0700f7ebe628c78'] = 'Añade un bloque de publicidad en las secciones seleccionadas de tu sitio web e-commerce.';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_33476c93475bba83cdcaac18e09b95ec'] = 'Este módulo requiere ser enganchado a una columna, pero tu tema no tiene implementada ninguna';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_070e16b4f77b90e802f789b5be583cfa'] = 'Error al subir el archivo.';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_254f642527b45bc260048e30704edb39'] = 'Configuración';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_a15e4232c6c1fc1e67816dd517e0e966'] = 'Imagen del anuncio';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_351ec5e81711303a312e244ec952f8e9'] = 'De manera predeterminada, la imagen aparecerá en la columna izquierda. Las dimensiones recomendadas son 155 x 163px.';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_4163f94824da4886254e88de13fbb863'] = 'Enlace de destino de la imagen';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_24c28ef67324898298e45026d8efabaf'] = 'Título del enlace de destino';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_78315dd2b27ef8037115b9f66351c155'] = 'Este título se mostrará cuando situe el ratón sobre el bloque de anuncios en su tienda.';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';


return $_MODULE;
