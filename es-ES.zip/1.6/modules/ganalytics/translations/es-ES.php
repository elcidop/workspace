<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{ganalytics}prestashop>ganalytics_d86cf69a8b82547a94ca3f6a307cf9a6'] = 'Google Analytics';
$_MODULE['<{ganalytics}prestashop>ganalytics_135d2522825fa02688ab25a2e1c88c73'] = 'Utilizando Google Analytics obtendrás importantes métricas relacionadas con tus clientes';
$_MODULE['<{ganalytics}prestashop>ganalytics_7ed5c154078e30b30b2f214299c5e9f5'] = '¿Estás seguro de que quieres desinstalar Google Analytics?. Perderás todos los datos relacionados con este módulo.';
$_MODULE['<{ganalytics}prestashop>ganalytics_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{ganalytics}prestashop>ganalytics_630f6dc397fe74e52d5189e2c80f282b'] = 'Volver a la lista';
$_MODULE['<{ganalytics}prestashop>ganalytics_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{ganalytics}prestashop>ganalytics_851bd83a102d143ee17d97f9e15e15af'] = 'ID de seguimiento de Google Analytics';
$_MODULE['<{ganalytics}prestashop>ganalytics_ad8e83a47926dcb12e8a8fccd7fcf604'] = 'Esta información está disponible en tu cuenta de Google Analytics';
$_MODULE['<{ganalytics}prestashop>ganalytics_bcd08e73ca9d8bfed2cccd50dd6d8328'] = 'Activar el seguimiento User-ID';
$_MODULE['<{ganalytics}prestashop>ganalytics_9bda6a2c3edca377eb901d7ea57c8b06'] = 'El User ID está establecido en el nivel de propiedad. Para encontrar una propiedad, haz clic en Admin, a continuación, selecciona una cuenta y una propiedad. En la columna de Propiedades, haz clic en Información de Seguimiento y a continuación en User ID';
$_MODULE['<{ganalytics}prestashop>ganalytics_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{ganalytics}prestashop>ganalytics_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{ganalytics}prestashop>ganalytics_612e1a524ec979815b12182c34e2daa0'] = 'El ID de cuenta ha sido actualizado correctamente';
$_MODULE['<{ganalytics}prestashop>ganalytics_8e7b67b44506b7ac6685da041a603044'] = 'Configuración User ID actualizada corectamente';
$_MODULE['<{ganalytics}prestashop>configuration_1f13d86a35be758509f9bdfcce5ec55d'] = 'Tus clientes están en todas partes: tu análisis debe ser capaz de seguirlos.';
$_MODULE['<{ganalytics}prestashop>configuration_7063e771c3bb338ba74ac4e4716dbae1'] = 'Google Analytics proporciona una imagen completa de tus clientes mediante el uso de anuncios, vídeos, sitios web, herramientas sociales, tablets y teléfonos inteligentes. Esto le permite servir mejor a tus clientes actuales y ganar otros nuevos.';
$_MODULE['<{ganalytics}prestashop>configuration_df15c5cf264eb769b087f9d81aff029f'] = 'Con la funcionalidad de comercio electrónico en Google Analytics, puede obtener una visión clara de métricas importantes sobre el comportamiento y la conversión del comprador, incluyendo:';
$_MODULE['<{ganalytics}prestashop>configuration_613c191b4a1f82a454b72a840d96eefd'] = 'La visualización de los detalles del producto';
$_MODULE['<{ganalytics}prestashop>configuration_d88b192dfe623e2a628a919b99fc1a4b'] = 'El rendimiento interno del merchandising';
$_MODULE['<{ganalytics}prestashop>configuration_ade6a18bb6c147db87bc9463240e455a'] = 'Las acciones de "Añadir al carrito"';
$_MODULE['<{ganalytics}prestashop>configuration_c975b6b93d71b19da73114c4adcedbda'] = 'El proceso de compra';
$_MODULE['<{ganalytics}prestashop>configuration_33f50b54625790316b86485ff3e794c4'] = 'Los clics de campañas internas';
$_MODULE['<{ganalytics}prestashop>configuration_89c48ff165eedcc3cd1bd0007115669d'] = 'Y las compras';
$_MODULE['<{ganalytics}prestashop>configuration_4632d86a96205013262bcfdd0279b39f'] = 'Los comerciantes pueden entender hasta qué punto llegan los usuarios en el proceso de compra y donde lo abandonan.';
$_MODULE['<{ganalytics}prestashop>configuration_16fafb5cce24f766bf2c8fcebecf76fc'] = 'Crea tu cuenta para comenzar.';
$_MODULE['<{ganalytics}prestashop>form-ps14_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';


return $_MODULE;
