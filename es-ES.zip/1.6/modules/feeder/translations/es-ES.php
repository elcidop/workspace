<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{feeder}prestashop>feeder_4dce2f12546b229088d3cc214c3c2f7d'] = 'Fuente de productos RSS';
$_MODULE['<{feeder}prestashop>feeder_8e08defbab5b0cf81a6a6b8472b8feda'] = 'Generar una fuente RSS para tus últimos productos.';


return $_MODULE;
