<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_4f29d8c727dcf2022ac241cb96c31083'] = 'Se devolvió un conjunto de registros vacío';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_f5c493141bb4b2508c5938fd9353291a'] = 'Mostrando %1$s de %2$s';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_77587239bf4c54ea493c7033e1dbf636'] = 'Apellidos';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_bc910f8bdf70f29374f496f05be0330c'] = 'Nombre';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Dirección de correo electrónico';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_d7e637a6e9ff116de2fa89551240a94d'] = 'Visitas';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_ec1ee973b8947391f8f014c76ac7379f'] = 'Pedidos válidos';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_1ff1b62d08d1195f073c6adac00f1894'] = 'Dinero gastado';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Mejores clientes';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_9a1643c70b51526dd35d546ef8e17b87'] = 'Añade una lista de los mejores clientes al Panel de control de Estadísticas.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_cb21e843b037359d0fb5b793fccf964f'] = 'Aumentar y mejorar la fidelización de clientes';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_c01d21a09f02b8e661114db60a0f60d4'] = 'Mantener un cliente satisfecho es más rentable que captar uno nuevo. Por lo tanto, es necesario ganarse su lealtad, para que vuelva a tu tienda.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_197bad7ad08abfd1dc45ab92f96f155d'] = 'El boca a boca es uno de los mejores medios para conseguir nuevos clientes. Un cliente insatisfecho puede dañar tu reputación y dificultar los objetivos de ventas marcados.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_bf0d87b5aa8d331563ee61f2ac82069d'] = 'Para alcanzar este objetivo, puedes organizar:';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_397a5e109a5897ee7d699050cbc93347'] = 'Operaciones puntuales: recompensas comerciales (ofertas especiales personalizadas, producto o servicio ofrecido), recompensas no comerciales (prioridad en el envío de un pedido o de un producto), recompensas pecuniarias (cupones de descuento, reembolsos).';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_4bc24eed56e0ba89fc3ab4e094d18d8a'] = 'Operaciones sostenibles: tarjetas clientes o puntos de fidelidad, que no sólo justifican la comunicación entre el comerciante y el cliente, sino que también ofrecen ventajas a los clientes (ofertas privadas exclusivas, descuentos).';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_2f408c42912e3afe23a0e4adcbe34b96'] = 'Estas operaciones incitan a los clientes a comprar productos y visitar tu tienda con mayor regularidad.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_998e4c5c80f27dec552e99dfed34889a'] = 'Exportar CSV';


return $_MODULE;
