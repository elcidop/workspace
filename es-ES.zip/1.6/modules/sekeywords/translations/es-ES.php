<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{sekeywords}prestashop>sekeywords_65b0b42febc8ea16db4652eab6f420a4'] = 'Palabras clave en los motores de búsqueda';
$_MODULE['<{sekeywords}prestashop>sekeywords_8effa630c1740a748801b881acb90fa6'] = 'Muestra qué palabras claves han dirigido a los visitantes a tu tienda.';
$_MODULE['<{sekeywords}prestashop>sekeywords_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{sekeywords}prestashop>sekeywords_9ed50bd6876a9273f2192c224b87657b'] = 'Identificar las palabras clave de los motores de búsqueda externos';
$_MODULE['<{sekeywords}prestashop>sekeywords_7acbda50735929f05f6f463e05bc7ead'] = 'Esta es una de las formas más comunes de encontrar un sitio web a través de un motor de búsqueda.';
$_MODULE['<{sekeywords}prestashop>sekeywords_4ad084c0b816ff9278765a00720caf32'] = 'La identificación de las palabras clave más populares introducidas por tus nuevos visitantes, te permite ver los productos que debes poner en la página de inicio de tu tienda, si deseas lograr una mejor visibilidad en los motores de búsqueda.';
$_MODULE['<{sekeywords}prestashop>sekeywords_359f9e79e746fa9f684e5cda9e60ca2e'] = '¿Cómo funciona?';
$_MODULE['<{sekeywords}prestashop>sekeywords_ec2184245585ba979912af9e34d738c6'] = 'Cuando un visitante llega a tu sitio web, el servidor web rastrea la URL del sitio de donde proviene. Este módulo analiza la URL y si encuentra una referencia a un motor de búsqueda conocido, registra las palabras clave incluidas en la búsqueda.';
$_MODULE['<{sekeywords}prestashop>sekeywords_ef79a74a2fd296e19e8cc58cdae91d43'] = 'Este módulo puede reconocer todos los motores de búsqueda listados en la página de estadísticas y motores de búsqueda de PrestaShop, ¡y puedes añadir más!';
$_MODULE['<{sekeywords}prestashop>sekeywords_dcbcf5d190af87351a16edd5f132c657'] = 'NOTA IMPORTANTE: en septiembre de 2013, Google decidió cifrar sus consultas de búsqueda mediante SSL. Esto significa que todas las herramientas de referencia del mundo (incluyendo ésta) son incapaces de identificar las palabras clave de Google.';
$_MODULE['<{sekeywords}prestashop>sekeywords_16d5f8dc3bc4411c85848ae9cf6a947a'] = '%d palabra clave encontrada para su búsqueda.';
$_MODULE['<{sekeywords}prestashop>sekeywords_5029f8eef402bb8ddd6191dffb5e7c19'] = '%d palabras claves coincidentes con su búsqueda.';
$_MODULE['<{sekeywords}prestashop>sekeywords_0849140171616600e8f2c35f0a225212'] = 'Filtrar por palabra clave';
$_MODULE['<{sekeywords}prestashop>sekeywords_6e632566b6e16dbd2273e83d7c53182b'] = 'Y mínimo de ocurrencias';
$_MODULE['<{sekeywords}prestashop>sekeywords_9639e32cab248434a17ab32237cb3b71'] = 'Aplicar';
$_MODULE['<{sekeywords}prestashop>sekeywords_867343577fa1f33caa632a19543bd252'] = 'Palabras clave';
$_MODULE['<{sekeywords}prestashop>sekeywords_e52e6aa1a43a0187e44f048f658db5f9'] = 'Ocurrencias';
$_MODULE['<{sekeywords}prestashop>sekeywords_998e4c5c80f27dec552e99dfed34889a'] = 'Exportar CSV';
$_MODULE['<{sekeywords}prestashop>sekeywords_7b48f6cc4a1dde7fca9597e717c2465f'] = 'No hay palabras clave';
$_MODULE['<{sekeywords}prestashop>sekeywords_e15832aa200f342e8f4ab580b43a72a8'] = 'Las 10 palabras clave más buscadas';
$_MODULE['<{sekeywords}prestashop>sekeywords_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Otras';


return $_MODULE;
