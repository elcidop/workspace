<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_e0de5a06213f21c55ca3283c009e0907'] = 'Bloque de privacidad de datos del cliente';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f192f208f0bc97af4c5213eee3e78793'] = 'Añade un bloque que muestra un mensaje sobre la privacidad de los datos del cliente.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuración actualizada';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Si acepta los términos del mensaje Privacidad de los datos del cliente, haga clic en la casilla de verificación que aparece a continuación.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_9a730b88a32c2932d18b8b6043cc4fb7'] = 'Mostrar en el formulario de creación de cuenta';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_88997f015a0ee407a5e797011ddd090d'] = 'Mensaje sobre la privacidad de los datos del cliente para el formulario de registro de clientes:';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'El mensaje sobre la privacidad de los datos del cliente, se mostrará en el formulario de registro del cliente.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b51d73fb490ad1245fa9b87042bbbbb7'] = 'Sugerencia: Si el mensaje sobre la privacidad de los datos del cliente es demasiado largo para ser escrito directamente en el formulario, puedes añadir un enlace a una de tus páginas. Esta puede ser creada fácilmente a través de la página "CMS" bajo el menú "Preferencias".';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_67ebed7cf9667003ad2047609440513a'] = 'Mostrar en el área de cliente';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fc67768369eadd8d4fb1e7839f5eae69'] = 'Mensaje de privacidad de los datos del cliente para el área de clientes:';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_432d64c20d5d06378d96c247c3f358f4'] = 'El mensaje de privacidad de los datos del cliente se mostrará en la página "Información personal" en el área de clientes.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_de1126ae0ac67eb4fda28cfad8429c79'] = 'Sugerencia: Si el mensaje sobre la privacidad de los datos del cliente es demasiado largo para ser escrito directamente en el formulario, puedes añadir un enlace a una de tus páginas. Esta puede ser creada fácilmente a través de la página "CMS" bajo el menú "Preferencias".';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Privacidad de los datos del cliente';


return $_MODULE;
